import unittest
from pubmed_paper_fetcher.fetcher import fetch_paper_ids, parse_paper_data

class TestPubMedFetcher(unittest.TestCase):
    
    def test_fetch_paper_ids(self):
        sample_query = "cancer"
        result = fetch_paper_ids(sample_query, debug=True)
        self.assertIsInstance(result, list)

    def test_parse_paper_data(self):
        sample_xml = """<PubmedArticleSet>
            <PubmedArticle>
                <MedlineCitation>
                    <PMID>123456</PMID>
                    <Article>
                        <ArticleTitle>Sample Title</ArticleTitle>
                        <PubDate><Year>2025</Year></PubDate>
                    </Article>
                    <AuthorList>
                        <Author>
                            <LastName>Doe</LastName>
                            <AffiliationInfo><Affiliation>Company X</Affiliation></AffiliationInfo>
                        </Author>
                    </AuthorList>
                </MedlineCitation>
            </PubmedArticle>
        </PubmedArticleSet>"""
        result = parse_paper_data(sample_xml)
        self.assertEqual(result[0]["PubmedID"], "123456")

if __name__ == "__main__":
    unittest.main()
