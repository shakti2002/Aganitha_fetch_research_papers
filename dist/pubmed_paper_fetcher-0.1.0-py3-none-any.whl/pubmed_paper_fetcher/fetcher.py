import requests
import pandas as pd
import re
import os
from typing import List, Dict, Optional
from dotenv import load_dotenv
from xml.etree import ElementTree as ET

# Load environment variables
env_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".env"))
load_dotenv(env_path)

PUBMED_API_URL = os.getenv("PUBMED_API_URL")
PUBMED_SUMMARY_URL = os.getenv("PUBMED_SUMMARY_URL")
PUBMED_FETCH_URL = os.getenv("PUBMED_FETCH_URL")

# Keywords indicating academic institutions
ACADEMIC_KEYWORDS = ["university", "college", "institute", "school", "research center", "hospital"]

def fetch_paper_ids(query: str, debug: bool = False) -> List[str]:
    """Fetch paper IDs from PubMed API."""
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": 50,
        "retmode": "json"
    }
    response = requests.get(PUBMED_API_URL, params=params)
    response.raise_for_status()

    if debug:
        print(f"PubMed API Response: {response.json()}")

    data = response.json()
    return data.get("esearchresult", {}).get("idlist", [])

def fetch_paper_details(paper_ids: List[str], debug: bool = False) -> List[Dict]:
    """Fetch paper details using paper IDs."""
    if not paper_ids:
        return []

    params = {"db": "pubmed", "id": ",".join(paper_ids), "retmode": "xml"}
    response = requests.get(PUBMED_FETCH_URL, params=params)
    response.raise_for_status()

    if debug:
        print("Fetched Paper Details:", response.text[:500])

    return parse_paper_data(response.text)

def parse_paper_data(xml_data: str) -> List[Dict]:
    """Parse XML response to extract paper details."""
    root = ET.fromstring(xml_data)
    papers = []

    for article in root.findall(".//PubmedArticle"):
        paper_id = article.find(".//PMID").text
        title = article.find(".//ArticleTitle").text
        pub_date = article.find(".//PubDate/Year")
        pub_date = pub_date.text if pub_date is not None else "Unknown"

        authors, company_affiliations = [], []
        corresponding_email = None

        for author in article.findall(".//Author"):
            name = author.find("LastName")
            if name is not None:
                full_name = name.text
                affiliation = author.find("AffiliationInfo/Affiliation")

                if affiliation and not any(word in affiliation.text.lower() for word in ACADEMIC_KEYWORDS):
                    authors.append(full_name)
                    company_affiliations.append(affiliation.text)

        email_match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", xml_data)
        if email_match:
            corresponding_email = email_match.group(0)

        if authors:
            papers.append({
                "PubmedID": paper_id,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": ", ".join(authors),
                "Company Affiliation(s)": ", ".join(company_affiliations),
                "Corresponding Author Email": corresponding_email
            })

    return papers

def save_to_csv(papers: List[Dict], filename: str):
    """Save results to CSV file."""
    df = pd.DataFrame(papers)
    df.to_csv(filename, index=False)
    print(f"Results saved to {filename}")
